-- 1
select * from estudiante;
select Nombre, Apellido from estudiante order by Apellido;
-- 2
select * from curso;
select * from curso where Creditos >= 3;
-- 3
select estudiante.Nombre, curso.Nombre as 'Nombre Curso' from estudiante inner join curso on estudiante.EstudianteID = curso.CursoID;
-- 4
select * from estudiante;
select * from inscripcion;
select * from estudiante left join inscripcion on estudiante.EstudianteID = inscripcion.EstudianteID; 
-- 5
select * from curso;
select * from inscripcion;
select * from curso right join inscripcion on curso.CursoID = inscripcion.EstudianteID order by curso.CursoID;
-- 6
select * from estudiante;
select * from departamento;

SELECT departamento.Nombre, COUNT(estudiante.EstudianteID) AS 'Cantidad Estudiantes'
FROM Departamento
JOIN Estudiante ON departamento.DepartamentoID = estudiante.DepartamentoID
GROUP BY departamento.Nombre;
-- 7
select * from estudiante;
select * from calificacion;

SELECT estudiante.EstudianteID, estudiante.Nombre, AVG(calificacion.Nota) AS 'Promedio Notas'
FROM Estudiante inner join Inscripcion ON estudiante.EstudianteID = inscripcion.EstudianteID
JOIN Calificacion ON inscripcion.InscripcionID = calificacion.InscripcionID
GROUP BY estudiante.EstudianteID, estudiante.Nombre;
-- 8
select * from clase;
select * from calificacion;
select * from curso;
select * from inscripcion;

SELECT clase.CursoID, MAX(calificacion.nota) AS 'Nota Maxima', MIN(calificacion.nota) AS 'Nota Minima'
FROM Clase
JOIN Calificacion ON clase.ClaseID = calificacion.InscripcionID
GROUP BY clase.CursoID;

-- 9
SELECT estudiante.Nombre, AVG(calificacion.Nota) AS promedio_notas
FROM Estudiante
JOIN Inscripcion ON estudiante.EstudianteID = inscripcion.EstudianteID
JOIN Calificacion  ON inscripcion.InscripcionID = calificacion.InscripcionID
GROUP BY estudiante.Nombre
ORDER BY promedio_notas DESC
LIMIT 5;

-- 10
select * from estudiante WHERE estudiante.EstudianteID = 1;

UPDATE Estudiante
SET estudiante.Email = 'nuevo_correo@hotmail.com'
WHERE estudiante.EstudianteID = 1;

-- 11

select * from inscripcion;
select * from estudiante;
select * from calificacion;

select * from inscripcion where inscripcion.EstudianteID = 45 and inscripcion.InscripcionID = 1;

delete from Inscripcion
where inscripcion.EstudianteID = 45 and inscripcion.InscripcionID = 1;
